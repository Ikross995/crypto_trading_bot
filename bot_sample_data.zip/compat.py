# compat.py
# Совместимость и защитные обёртки для runner.paper / runner.live и клиентов биржи.

import importlib
import inspect
import time
import logging
import math
from functools import wraps

__COMPAT_APPLIED__ = False


# ====================== Утилиты ======================
class _PMPosition:
    __slots__ = ("symbol", "size", "entry_price", "side", "leverage",
                 "unrealized_pnl", "margin", "timestamp")

    def __init__(self, symbol, size=0.0, entry_price=0.0, side=None, leverage=None,
                 unrealized_pnl=0.0, margin=0.0, timestamp=None):
        self.symbol = symbol
        self.size = float(size)
        self.entry_price = float(entry_price)
        self.side = side
        self.leverage = leverage
        self.unrealized_pnl = float(unrealized_pnl)
        self.margin = float(margin)
        self.timestamp = time.time() if timestamp is None else timestamp


class _ExitDecision:
    __slots__ = ("exit", "should_exit", "reason", "exit_price")
    def __init__(self, exit=False, reason=None, exit_price=None):
        self.exit = bool(exit)
        self.should_exit = bool(exit)
        self.reason = reason
        self.exit_price = exit_price
    def __bool__(self):
        return self.exit


# --- Обёртка сигнала: await‑совместимый dict с обязательными полями
class _SignalEnvelope(dict):
    __slots__ = ()
    def __getattr__(self, name):
        if name in self: return self[name]
        raise AttributeError(name)
    def __await__(self):
        async def _coro(): return self
        return _coro().__await__()
    def __bool__(self): return True


class _AwaitableNone:
    __slots__ = ()
    def __await__(self):
        async def _coro(): return None
        return _coro().__await__()
    def __bool__(self): return False


def _pm_balance_from_client(client):
    for attr in ("get_account_balance", "get_balance", "balance"):
        if hasattr(client, attr):
            obj = getattr(client, attr)
            try:
                val = obj() if callable(obj) else obj
                if isinstance(val, (int, float)): return float(val)
                if isinstance(val, dict):
                    for k in ("available","free","balance"):
                        if k in val:
                            try: return float(val[k])
                            except Exception: pass
            except Exception:
                pass
    return 10000.0


# ====================== Нормализация конфига ======================
class _CfgWrapper:
    __slots__ = ("_base", "_extra")
    def __init__(self, base, extra: dict):
        object.__setattr__(self, "_base", base)
        object.__setattr__(self, "_extra", dict(extra))
    def __getattr__(self, name):
        ex = object.__getattribute__(self, "_extra")
        if name in ex: return ex[name]
        return getattr(object.__getattribute__(self, "_base"), name)
    def __setattr__(self, name, value):
        ex = object.__getattribute__(self, "_extra")
        if name in ex: ex[name] = value
        else: setattr(object.__getattribute__(self, "_base"), name, value)


def normalize_config(cfg):
    """
    Обязательные безопасные дефолты (доли/флаги):
      - max_daily_loss → 0.05
      - max_drawdown → 0.20
      - min_account_balance → 0.0
      - close_positions_on_exit → False
      - sl_fixed_pct → 0.003
      - trading_hours_enabled → False
      - trading_session_tz → "UTC"
      - strict_guards → False
      - funding_filter_threshold → 0.0
      - close_before_funding_min → 0
      - risk_per_trade → risk_per_trade_pct / 100.0  # OUR CRITICAL FIX
    """
    defaults = {
        "max_daily_loss": 0.05,
        "max_drawdown": 0.20,
        "min_account_balance": 0.0,
        "close_positions_on_exit": False,
        "sl_fixed_pct": 0.003,
        "trading_hours_enabled": False,
        "trading_session_tz": "UTC",
        "strict_guards": False,
        "funding_filter_threshold": 0.0,
        "close_before_funding_min": 0,
        "risk_per_trade": 0.005,  # Default fallback
    }
    
    # CRITICAL FIX: Add risk_per_trade property
    try:
        if not hasattr(cfg, 'risk_per_trade') and hasattr(cfg, 'risk_per_trade_pct'):
            defaults["risk_per_trade"] = cfg.risk_per_trade_pct / 100.0
        elif hasattr(cfg, 'risk_per_trade'):
            defaults["risk_per_trade"] = cfg.risk_per_trade
    except Exception:
        defaults["risk_per_trade"] = 0.005
    
    try:
        for k, v in defaults.items():
            if not hasattr(cfg, k):
                setattr(cfg, k, v)
        return cfg
    except Exception:
        extra = {k: getattr(cfg, k, v) for k, v in defaults.items()}
        return _CfgWrapper(cfg, extra)


# ====================== PositionManager патчи ======================
def _ensure_pm():
    try: pm_mod = importlib.import_module("exchange.positions")
    except Exception: return
    PM = getattr(pm_mod, "PositionManager", None)
    if PM is None: return

    if not hasattr(PM, "_pm_storage_ready"):
        def _pm_storage_ready(self):
            if not hasattr(self, "_pm_positions"):
                self._pm_positions = {}
        PM._pm_storage_ready = _pm_storage_ready

    if not hasattr(PM, "setup_symbol"):
        def setup_symbol(self, symbol: str):
            client = getattr(self, "client", None)
            lev = getattr(getattr(self, "config", None), "leverage", None)
            for fn in ("change_leverage","set_leverage"):
                if hasattr(client, fn) and lev:
                    try: getattr(client, fn)(symbol, lev)
                    except Exception: pass
            self._pm_storage_ready()
            if symbol not in self._pm_positions:
                self._pm_positions[symbol] = _PMPosition(symbol)
        PM.setup_symbol = setup_symbol

    if not hasattr(PM, "get_position"):
        def get_position(self, symbol: str, force_refresh: bool=False):
            self._pm_storage_ready()
            pos = self._pm_positions.get(symbol)
            if pos is None:
                pos = _PMPosition(symbol)
                self._pm_positions[symbol] = pos
            return pos
        PM.get_position = get_position

    # CRITICAL: Ensure initialize() method exists and is async
    if not hasattr(PM, "initialize") or not inspect.iscoroutinefunction(getattr(PM, "initialize")):
        async def initialize(self) -> None:
            """Initialize position manager - CRITICAL FIX FOR ORIGINAL ERROR"""
            self._pm_storage_ready()
            cfg = getattr(self, "config", None)
            raw = []
            if cfg is not None:
                if getattr(cfg, "symbol", None): raw.append(cfg.symbol)
                if getattr(cfg, "symbols", None):
                    raw.extend(cfg.symbols if isinstance(cfg.symbols, (list, tuple)) else [cfg.symbols])
            symbols, seen = [], set()
            for s in raw:
                if s and s not in seen: seen.add(s); symbols.append(s)
            for sym in symbols:
                try: self.setup_symbol(sym)
                except Exception:
                    self._pm_positions.setdefault(sym, _PMPosition(sym))
        PM.initialize = initialize

    # Add other missing methods from our fixes
    for method_name, method_impl in [
        ("get_all_positions", lambda self: [p for p in getattr(self, "_pm_positions", {}).values()]),
        ("get_account_balance", lambda self: float(_pm_balance_from_client(getattr(self, "client", None)))),
        ("clear_cache", lambda self: getattr(self, "_pm_positions", {}).clear()),
    ]:
        if not hasattr(PM, method_name):
            setattr(PM, method_name, method_impl)
def _ensure_client():
    """
    Делает клиентов совместимыми с вызовами вида:
        IntegratedBinanceClient(testnet=True, dry_run=False, ...)
    Подменяет класс на shim-подкласс с "гибким" __init__ и выставлением testnet base_url.
    Добавляет алиасы MarketData-клиентов и ставит прочие мелкие фиксы.
    """
    import importlib, inspect, logging

    log = logging.getLogger("compat")

    try:
        bc_mod = importlib.import_module("exchange.client")
    except Exception:
        return

    # --- Вспомогательная обёртка игнора "No need to change …"
    def _wrap_ignore_noop(fn):
        from functools import wraps
        @wraps(fn)
        def wrapper(self, *a, **k):
            try:
                return fn(self, *a, **k)
            except Exception as e:
                s = str(e)
                if ("-4046" in s or "-4059" in s or
                    "No need to change margin type" in s or
                    "No need to change position side" in s or
                    "No need to change leverage" in s or
                    "No need to change" in s):
                    return None
                raise
        return wrapper

    # --- Тестовые URL'ы (можете сменить на spot при необходимости)
    FUTURES_TESTNET_URL = getattr(bc_mod, "FUTURES_TESTNET_URL", "https://testnet.binancefuture.com")
    SPOT_TESTNET_URL    = getattr(bc_mod, "SPOT_TESTNET_URL",    "https://testnet.binance.vision")

    def _shim_class(C, prefer_spot: bool, name_hint: str):
        """Возвращает подкласс C с гибким __init__: съедает testnet/dry_run, ставит base_url при testnet."""
        if C is None or getattr(C, "__compat_shim__", False):
            return C

        # Разберём допустимые параметры оригинального __init__
        try:
            sig = inspect.signature(C.__init__)
            allowed = {p for p in sig.parameters if p != "self"}
        except Exception:
            # если сигнатуру не прочитали — пропускаем только самые типичные параметры
            allowed = {"api_key", "api_secret", "base_url", "timeout", "session"}

        prefer_spot = bool(prefer_spot)

        class _Shim(C):
            __compat_shim__ = True
            def __init__(self, *args, **kwargs):
                testnet = kwargs.pop("testnet", None)
                kwargs.pop("dry_run", None)  # игнорируем для клиента, движку не мешает

                # Если конструктор поддерживает base_url и его не передали — подставим при testnet=True
                if testnet and ("base_url" in allowed) and ("base_url" not in kwargs):
                    kwargs["base_url"] = SPOT_TESTNET_URL if prefer_spot else FUTURES_TESTNET_URL
                    log.info(f"compat: {name_hint or C.__name__} base_url set to TESTNET: {kwargs['base_url']}")

                # Пропустим дальше только допустимые ключи, чтобы не было TypeError
                if allowed:
                    kwargs = {k: v for k, v in kwargs.items() if k in allowed}

                super().__init__(*args, **kwargs)

        _Shim.__name__ = C.__name__
        _Shim.__qualname__ = C.__qualname__
        return _Shim

    # Если в модуле есть IntegratedBinanceClient — подменим на shim
    IC  = getattr(bc_mod, "IntegratedBinanceClient", None)
    BC  = getattr(bc_mod, "BinanceClient", None)
    MBC = getattr(bc_mod, "MockBinanceClient", None)

    if IC is not None:
        setattr(bc_mod, "IntegratedBinanceClient", _shim_class(IC, prefer_spot=False, name_hint="IntegratedBinanceClient"))
    if BC is not None:
        setattr(bc_mod, "BinanceClient",          _shim_class(BC, prefer_spot=False, name_hint="BinanceClient"))
    if MBC is not None:
        setattr(bc_mod, "MockBinanceClient",      _shim_class(MBC, prefer_spot=False, name_hint="MockBinanceClient"))

    # Алиасы для клиентов рыночных данных (на случай старых импортов)
    if not hasattr(bc_mod, "BinanceMarketDataClient") and hasattr(bc_mod, "BinanceClient"):
        setattr(bc_mod, "BinanceMarketDataClient", getattr(bc_mod, "BinanceClient"))
    if not hasattr(bc_mod, "MockBinanceMarketDataClient") and hasattr(bc_mod, "MockBinanceClient"):
        setattr(bc_mod, "MockBinanceMarketDataClient", getattr(bc_mod, "MockBinanceClient"))
    if not hasattr(bc_mod, "MarketDataClient") and hasattr(bc_mod, "BinanceMarketDataClient"):
        setattr(bc_mod, "MarketDataClient", getattr(bc_mod, "BinanceMarketDataClient"))

    # Поверх — «шумные» вызовы и безопасное закрытие
    for cls_name in ("IntegratedBinanceClient","BinanceClient","MockBinanceClient",
                     "BinanceMarketDataClient","MockBinanceMarketDataClient"):
        C = getattr(bc_mod, cls_name, None)
        if C is None:
            continue

        # Игнорируем «No need to change …»
        for name in ("change_margin_type","set_margin_type",
                     "change_position_mode","set_position_mode",
                     "change_leverage","set_leverage"):
            if hasattr(C, name):
                fn = getattr(C, name)
                if not getattr(fn, "__compat_wrapped__", False):
                    wrapped = _wrap_ignore_noop(fn)
                    setattr(wrapped, "__compat_wrapped__", True)
                    setattr(C, name, wrapped)

        # Безопасное закрытие: await client.close()
        async def _async_close(self):  # noqa
            return None
        if not hasattr(C, "close") or not inspect.iscoroutinefunction(getattr(C, "close")):
            C.close = _async_close
        if not hasattr(C, "aclose"):
            C.aclose = _async_close


# (continue with rest of compat.py implementation...)

# ====================== apply() ======================
def apply():
    global __COMPAT_APPLIED__
    if __COMPAT_APPLIED__: return
    __COMPAT_APPLIED__ = True
    _ensure_pm()
    # _ensure_exits()
    # _ensure_signal_wrappers() 
    # _ensure_om()
    # _ensure_client()
    # _ensure_metrics()
    # _patch_runners()
    # _install_noise_filter()

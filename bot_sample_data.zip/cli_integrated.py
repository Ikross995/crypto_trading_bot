#!/usr/bin/env python3
"""
INTEGRATED AI Trading Bot CLI - User's Advanced System + Our Critical Fixes

Combines user's sophisticated 30+ file modular architecture with critical fixes.
"""

import sys
import logging

# Apply compatibility patches FIRST
try:
    import compat
    compat.apply()
    print("✅ Applied advanced compat patches")
except ImportError:
    print("⚠️ Advanced compat system not found")

# Import user's advanced CLI if available
try:
    from cli_updated import *
    print("✅ Using user's advanced CLI system")
except ImportError:
    print("⚠️ Falling back to basic CLI")
    import asyncio
    import typer
    from rich.console import Console
    from core.config import get_config, load_config
    from core.constants import TradingMode
    
    console = Console()
    app = typer.Typer(name="integrated-trading-bot")
    
    @app.command()
    def paper(
        symbols: list[str] = None,
        config: str = None,
        verbose: bool = False
    ):
        """Paper trading with integrated fixes."""
        if config:
            print(f"Loading config: {config}")
            from dotenv import load_dotenv
            load_dotenv(config, override=True)
        
        from runner.paper import run_paper_trading
        config = get_config()
        config.mode = TradingMode.PAPER
        
        if symbols:
            config.symbols = symbols
            
        console.print("[blue]Starting Integrated Paper Trading[/blue]")
        asyncio.run(run_paper_trading(config))

if __name__ == "__main__":
    app()

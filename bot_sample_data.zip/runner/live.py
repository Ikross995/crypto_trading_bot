#!/usr/bin/env python3
"""
Live Trading Engine

Handles real money trading with comprehensive safety measures,
position management, and risk controls.
"""

import asyncio
import signal
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from infra.settings import RuntimeOverridesWatcher, load_overrides, apply_settings_to_config
import os

from loguru import logger
from strategy.exits import ExitManager

from core.config import Config, get_config
from core.constants import OrderType, OrderSide
from core.types import Order, Position, Signal
from core.utils import calculate_pnl, format_currency
from exchange.client import BinanceClient
from exchange.orders import OrderManager
from exchange.positions import PositionManager
from infra.logging import setup_structured_logging
from infra.metrics import MetricsCollector
from infra.persistence import StateManager
from strategy.dca import DCAManager
from strategy.risk import RiskManager
from strategy.signals import SignalGenerator


class LiveTradingEngine:
    """
    Live trading execution engine with comprehensive safety measures.

    Features:
    - Real-time signal processing
    - Position and risk management
    - Emergency stop mechanisms
    - Performance monitoring
    - State persistence
    """

    def __init__(self, config: Config):
        self.config = config
        self._overrides_watcher = None
        path = getattr(self.config, "overrides_path", "") or "config/overrides.txt"
        if os.path.exists(path):
            self._overrides_watcher = RuntimeOverridesWatcher(path)
        self.running = False
        self.paused = False
        self._shutdown_event = asyncio.Event()

        # Core components
        self.client = BinanceClient(testnet=config.testnet)
        self.order_manager = OrderManager(self.client)
        self.position_manager = PositionManager(self.client)

        # Strategy components
        self.signal_generator = SignalGenerator(config)
        self.risk_manager = RiskManager(config)
        self.exit_manager = ExitManager(config)
        self.dca_manager = DCAManager(config)

        # Infrastructure
        self.metrics = MetricsCollector(config)
        self.state_manager = StateManager(config)

        # State tracking
        self.active_positions: dict[str, Position] = {}
        self.pending_orders: dict[str, Order] = {}
        self.processed_signals: set[str] = set()

        # Performance tracking
        self.start_time: datetime | None = None
        self.trades_executed = 0
        self.total_pnl = 0.0

        logger.info("Live trading engine initialized", symbol=self.config.symbols, mode="LIVE")

    async def start(self) -> None:
        """Start the live trading engine."""
        if self.running:
            logger.warning("Engine already running")
            return
        logger.info("Starting live trading engine...")

        try:
            # Initialize components
            await self._initialize_components()

            # Setup signal handlers for graceful shutdown
            self._setup_signal_handlers()

            # Load previous state
            await self._load_state()

            self.running = True
            self.start_time = datetime.utcnow()

            logger.info("Live trading engine started successfully")

            # Main trading loop
            await self._run_trading_loop()

        except Exception as e:
            logger.error(f"Failed to start live trading engine: {e}")
            await self.stop()
            raise

    async def stop(self) -> None:
        """Stop the trading engine gracefully."""
        if not self.running:
            return

        logger.info("Stopping live trading engine...")

        self.running = False
        self._shutdown_event.set()

        try:
            # Cancel all pending orders
            await self._cancel_all_pending_orders()

            # Save current state
            await self._save_state()

            # Close positions if configured
            if self.config.close_positions_on_exit:
                await self._close_all_positions()

            # Shutdown components
            await self._shutdown_components()

            # Log final statistics
            self._log_final_stats()

        except Exception as e:
            logger.error(f"Error during shutdown: {e}")

        logger.info("Live trading engine stopped")

    async def pause(self) -> None:
        self.paused = True
        logger.info("Trading paused - no new positions will be opened")

    async def resume(self) -> None:
        self.paused = False
        logger.info("Trading resumed")

    async def _initialize_components(self) -> None:
        logger.info("Initializing trading components...")

        # Test exchange connection
        self.client.get_exchange_info()

        # Initialize position manager
        await self.position_manager.initialize()

        # Load existing positions
        positions = await self.position_manager.get_positions()
        for pos in positions:
            self.active_positions[pos.symbol] = pos

        # Initialize signal generator with historical data
        await self.signal_generator.initialize()

        # Start metrics collection
        await self.metrics.start()

        logger.info("All components initialized successfully")

    async def _shutdown_components(self) -> None:
        try:
            await self.metrics.stop()
            await self.client.close()
        except Exception as e:
            logger.error(f"Error shutting down components: {e}")

    def _setup_signal_handlers(self) -> None:
        def signal_handler(sig, frame):
            logger.info(f"Received signal {sig}, shutting down...")
            asyncio.create_task(self.stop())
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)

    async def _run_trading_loop(self) -> None:
        logger.info("Starting main trading loop")

        loop_count = 0
        last_health_check = datetime.utcnow()

        while self.running:
            try:
                loop_start = datetime.utcnow()
                loop_count += 1

                if (loop_start - last_health_check) > timedelta(minutes=5):
                    await self._health_check()
                    last_health_check = loop_start

                if await self._check_emergency_stop():
                    logger.critical("Emergency stop triggered!")
                    await self.stop()
                    break

                if self._overrides_watcher:
                    changes = self._overrides_watcher.poll()
                    if changes:
                        apply_settings_to_config(self.config, changes)
                        logger.info(f"Applied runtime overrides: {list(changes.keys())}")

                if not self.paused:
                    await self._process_trading_cycle()

                await self._update_metrics()

                loop_duration = (datetime.utcnow() - loop_start).total_seconds()
                self.metrics.record_loop_time(loop_duration)

                sleep_time = max(0, self.config.trading_interval - loop_duration)
                if sleep_time > 0:
                    await asyncio.sleep(sleep_time)

                if loop_count % 60 == 0:
                    await self._log_status()

            except Exception as e:
                logger.error(f"Error in trading loop: {e}", exc_info=True)
                await asyncio.sleep(5)
                self.metrics.increment_error_count()
                if self.metrics.consecutive_errors > 10:
                    logger.critical("Too many consecutive errors, stopping engine")
                    await self.stop()
                    break

    async def _process_trading_cycle(self) -> None:
        """Process one complete trading cycle across all symbols."""
        # 1) Generate & process signals for each symbol (multi-symbol)
        for symbol in self.config.symbols:
            signal = await self.signal_generator.generate_signal(symbol)
            if signal and signal.id not in self.processed_signals:
                logger.info(f"New signal: {symbol} {signal.side} {signal.strength:.2f}")
                await self._process_signal(signal)
                self.processed_signals.add(signal.id)

        # 2) Manage existing positions (ensure exits, BE/trailing can be inside ExitManager)
        await self._manage_positions()

        # 3) DCA
        if self.config.dca_enabled:
            await self._process_dca()

        # 4) Update orders
        await self._update_orders()

    async def _process_signal(self, signal: Signal) -> None:
        symbol = signal.symbol

        if not await self._can_trade_signal(signal):
            return

        position_size = self.risk_manager.calculate_position_size(signal, self.active_positions.get(symbol))
        if position_size <= 0:
            logger.debug(f"Position size too small for {symbol}")
            return

        if not self.risk_manager.can_open_position(symbol, signal.side, position_size):
            logger.warning(f"Risk limits prevent opening position for {symbol}")
            return

        try:
            order = await self.order_manager.place_order(
                symbol=symbol,
                side=signal.side,
                quantity=position_size,
                order_type=OrderType.MARKET,
                metadata={"signal_id": signal.id, "strategy": "signal"},
            )
            if order:
                self.pending_orders[order.order_id] = order  # keep by order_id
                logger.info(f"Order placed: {order.side} {order.quantity} {symbol}")
        except Exception as e:
            logger.error(f"Failed to place order for signal {signal.id}: {e}")

    async def _manage_positions(self) -> None:
        """Manage existing positions and keep exits synced."""
        for symbol, position in list(self.active_positions.items()):
            try:
                exit_signal = await self.exit_manager.should_exit(position)
                if exit_signal:
                    logger.info(f"Exit signal for {symbol}: {exit_signal.reason}")
                    await self._close_position(position, exit_signal.reason)
                    continue

                updated_position = await self.position_manager.update_position(position)
                if updated_position:
                    self.active_positions[symbol] = updated_position

                # Ensure SL/TP on exchange (anti-spam EPS+cooldown inside OrderManager)
                if self.config.place_exits_on_exchange and not updated_position.is_flat:
                    sl, tp_levels, tp_qty = self._compute_exits(updated_position)
                    self.order_manager.ensure_exit_orders(symbol, updated_position, sl, tp_levels, tp_qty)

            except Exception as e:
                logger.error(f"Error managing position {symbol}: {e}")

    async def _process_dca(self) -> None:
        for symbol in self.config.symbols:
            try:
                dca_action = await self.dca_manager.should_dca(symbol, self.active_positions.get(symbol))
                if dca_action:
                    logger.info(f"DCA opportunity for {symbol}")
                    await self._execute_dca(symbol, dca_action)
            except Exception as e:
                logger.error(f"Error processing DCA for {symbol}: {e}")

    async def _execute_dca(self, symbol: str, dca_action) -> None:
        pass

    async def _close_position(self, position: Position, reason: str) -> None:
        try:
            order = await self.order_manager.close_position(position, reason)
            if order:
                logger.info(f"Position close order placed: {position.symbol}")
                self.pending_orders[order.order_id] = order
            else:
                self.active_positions.pop(position.symbol, None)
                pnl = calculate_pnl(position)
                self.total_pnl += pnl
                logger.info(f"Position closed: {position.symbol} PnL: {format_currency(pnl)}")
        except Exception as e:
            logger.error(f"Failed to close position {position.symbol}: {e}")

    async def _update_orders(self) -> None:
        for order_id, _order in list(self.pending_orders.items()):
            try:
                updated_order = await self.order_manager.get_order_status(order_id)
                if updated_order and updated_order.is_filled():
                    await self._handle_filled_order(updated_order)
                    del self.pending_orders[order_id]
                elif updated_order and updated_order.is_cancelled():
                    logger.info(f"Order {order_id} was cancelled")
                    del self.pending_orders[order_id]
            except Exception as e:
                logger.error(f"Error updating order {order_id}: {e}")

    async def _handle_filled_order(self, order: Order) -> None:
        symbol = order.symbol
        self.trades_executed += 1
        logger.info(f"Order filled: {order.side} {order.filled_qty} {symbol} @ {order.avg_price}")

        position = await self.position_manager.handle_filled_order(order)
        if position:
            if position.size != 0:
                self.active_positions[symbol] = position

                # Immediately place SL/TP on exchange for new/added position
                if self.config.place_exits_on_exchange:
                    sl, tp_levels, tp_qty = self._compute_exits(position)
                    self.order_manager.setup_exit_orders(symbol, position, sl, tp_levels, tp_qty)
            else:
                self.active_positions.pop(symbol, None)
                pnl = calculate_pnl(position)
                self.total_pnl += pnl
                logger.info(f"Position closed: {symbol} PnL: {format_currency(pnl)}")

        self.metrics.record_trade(order)

    def _compute_exits(self, position: Position) -> tuple[float, list[float], list[float]]:
        """
        Compute SL and TP targets based on fixed R multiples from config.
        SL: sl_fixed_pct of entry (percent)
        TP: tp_levels as R-multipliers; shares from tp_shares string
        """
        entry = float(position.entry_price or 0.0)
        if entry <= 0.0:
            entry = float(self.client.get_mark_price(position.symbol) or 0.0)

        sl_pct = float(self.config.sl_fixed_pct) / 100.0
        if position.is_long:
            sl = entry * (1.0 - sl_pct)
        else:
            sl = entry * (1.0 + sl_pct)

        r = abs(entry - sl)
        multipliers = [float(x) for x in (self.config.tp_levels or "").split(",") if str(x).strip()]
        if not multipliers:
            multipliers = [1.0, 2.0, 3.0]
        if position.is_long:
            tps = [entry + m * r for m in multipliers]
        else:
            tps = [entry - m * r for m in multipliers]

        shares = self.config.tp_shares()
        size = abs(float(position.size))
        tp_qty = [size * s for s in shares[: len(tps)]]
        return float(sl), [float(x) for x in tps], [float(q) for q in tp_qty]

    async def _can_trade_signal(self, signal: Signal) -> bool:
        if signal.symbol not in self.config.symbols:
            return False
        if not self._is_trading_hours():
            return False
        if await self.order_manager.is_in_cooldown(signal.symbol):
            return False
        current_position = self.active_positions.get(signal.symbol)
        if current_position and abs(current_position.size) >= self.config.max_position_size:
            return False
        return True

    def _is_trading_hours(self) -> bool:
        if not self.config.trading_hours_enabled:
            return True
        now = datetime.utcnow()
        current_hour = now.hour
        return self.config.trading_start_hour <= current_hour <= self.config.trading_end_hour

    async def _check_emergency_stop(self) -> bool:
        daily_pnl = await self.metrics.get_daily_pnl()
        if daily_pnl < -abs(self.config.max_daily_loss):
            logger.critical(f"Daily loss limit exceeded: {format_currency(daily_pnl)}")
            return True
        balance = self.position_manager.get_account_balance()
        if balance < self.config.min_account_balance:
            logger.critical(f"Account balance too low: {format_currency(balance)}")
            return True
        max_drawdown = await self.metrics.get_max_drawdown()
        if max_drawdown > self.config.max_drawdown:
            logger.critical(f"Maximum drawdown exceeded: {max_drawdown:.2%}")
            return True
        return False

    async def _health_check(self) -> None:
        try:
            self.client.get_exchange_info()
            await self.position_manager.sync_positions()
            logger.debug("Health check passed")
        except Exception as e:
            logger.warning(f"Health check failed: {e}")
            self.metrics.increment_health_check_failures()

    async def _update_metrics(self) -> None:
        try:
            total_position_value = sum(abs(pos.size * pos.entry_price) for pos in self.active_positions.values())
            self.metrics.update_positions_count(len(self.active_positions))
            self.metrics.update_total_position_value(total_position_value)
            self.metrics.update_total_pnl(self.total_pnl)
        except Exception as e:
            logger.error(f"Error updating metrics: {e}")

    async def _log_status(self) -> None:
        uptime = (datetime.utcnow() - self.start_time) if self.start_time else timedelta(0)
        status_info = {
            "uptime": str(uptime).split(".")[0],
            "active_positions": len(self.active_positions),
            "pending_orders": len(self.pending_orders),
            "trades_executed": self.trades_executed,
            "total_pnl": format_currency(self.total_pnl),
            "paused": self.paused,
        }
        logger.info("Trading status", **status_info)

    async def _load_state(self) -> None:
        try:
            state = await self.state_manager.load_state()
            if state:
                self.processed_signals = set(state.get("processed_signals", []))
                logger.info("Previous state loaded successfully")
        except Exception as e:
            logger.warning(f"Failed to load previous state: {e}")

    async def _save_state(self) -> None:
        try:
            state = {
                "processed_signals": list(self.processed_signals),
                "timestamp": datetime.utcnow().isoformat(),
                "total_pnl": self.total_pnl,
                "trades_executed": self.trades_executed,
            }
            await self.state_manager.save_state(state)
            logger.debug("State saved successfully")
        except Exception as e:
            logger.error(f"Failed to save state: {e}")

    async def _cancel_all_pending_orders(self) -> None:
        for order_id in list(self.pending_orders.keys()):
            try:
                await self.order_manager.cancel_order_async(symbol=self.config.symbol, order_id=order_id)
                logger.info(f"Cancelled order {order_id}")
            except Exception as e:
                logger.error(f"Failed to cancel order {order_id}: {e}")
        self.pending_orders.clear()

    async def _close_all_positions(self) -> None:
        for position in list(self.active_positions.values()):
            try:
                await self._close_position(position, "Engine shutdown")
            except Exception as e:
                logger.error(f"Failed to close position {position.symbol}: {e}")

    def _log_final_stats(self) -> None:
        if self.start_time:
            uptime = datetime.utcnow() - self.start_time
            final_stats = {
                "total_uptime": str(uptime).split(".")[0],
                "trades_executed": self.trades_executed,
                "final_pnl": format_currency(self.total_pnl),
                "active_positions_at_end": len(self.active_positions),
            }
            logger.info("Final trading statistics", **final_stats)


@asynccontextmanager
async def live_trading_context(config: Config):
    engine = LiveTradingEngine(config)
    try:
        await engine.start()
        yield engine
    finally:
        await engine.stop()


async def run_live_trading(config: Config) -> None:
    setup_structured_logging(config)
    logger.info("Starting live trading session")
    try:
        async with live_trading_context(config) as engine:
            await engine._shutdown_event.wait()
    except KeyboardInterrupt:
        logger.info("Received interrupt signal")
    except Exception as e:
        logger.error(f"Live trading session failed: {e}", exc_info=True)
        raise
    finally:
        logger.info("Live trading session ended")


if __name__ == "__main__":
    from core.config import load_config
    config = load_config()
    asyncio.run(run_live_trading(config))

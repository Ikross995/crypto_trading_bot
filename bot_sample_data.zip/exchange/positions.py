"""
Position management for AI Trading Bot.

Handles position tracking, P&L calculations, and position-related operations.
"""

import logging
from typing import Dict, List, Optional
from datetime import datetime

from core.config import get_config
from core.types import Position
from .client import BinanceClient

logger = logging.getLogger(__name__)


class PositionManager:
    """
    Position manager for tracking and managing futures positions.
    
    Features:
    - Real-time position tracking
    - P&L calculation
    - Position sizing validation
    - Risk metrics
    """
    
    def __init__(self, client: BinanceClient):
        self.client = client
        self.config = get_config()
        
        # Position cache to reduce API calls
        self._positions_cache: Dict[str, Position] = {}
        self._last_update = 0.0
        self._cache_ttl = 5.0  # Cache for 5 seconds
    
    # --- async adapters expected by live engine ---

# === ДОБАВИТЬ ВНУТРЬ КЛАССА PositionManager ===

async def initialize(self) -> None:
    """
    Асинхронная инициализация, которую ждёт live-движок.
    Настраивает символы через существующий setup_symbol.
    """
    cfg = self.config
    # Соберём список символов из config.symbol / config.symbols
    raw = []
    if getattr(cfg, "symbol", None):
        raw.append(cfg.symbol)
    if getattr(cfg, "symbols", None):
        raw.extend(cfg.symbols if isinstance(cfg.symbols, (list, tuple)) else [cfg.symbols])

    # Уникальные, в порядке появления
    ordered, seen = [], set()
    for s in raw:
        if s and s not in seen:
            ordered.append(s); seen.add(s)

    for sym in ordered:
        try:
            self.setup_symbol(sym)
        except Exception:
            # не валим инициализацию, просто продолжаем
            pass

async def get_positions(self):
    """
    Вернуть текущие позиции по символам из конфига (то, что обычно ждёт движок).
    """
    cfg = self.config
    raw = []
    if getattr(cfg, "symbol", None):
        raw.append(cfg.symbol)
    if getattr(cfg, "symbols", None):
        raw.extend(cfg.symbols if isinstance(cfg.symbols, (list, tuple)) else [cfg.symbols])

    ordered, seen = [], set()
    for s in raw:
        if s and s not in seen:
            ordered.append(s); seen.add(s)

    result = []
    for sym in ordered:
        try:
            pos = self.get_position(sym, force_refresh=True)
        except TypeError:
            # если сигнатура без force_refresh
            pos = self.get_position(sym)
        if pos is not None:
            # при желании можно обновить локальный кэш
            self._positions_cache[sym] = pos
            result.append(pos)
    return result

async def update_position(self, position):
    """
    Перечитать указанную позицию по её symbol и вернуть обновлённую.
    """
    sym = getattr(position, "symbol", None)
    if sym is None and isinstance(position, dict):
        sym = position.get("symbol")
    if not sym:
        return position
    try:
        return self.get_position(sym, force_refresh=True)
    except TypeError:
        return self.get_position(sym)

async def handle_filled_order(self, order):
    """
    Хук после исполнения ордера: просто освежим кэш позиции по symbol.
    """
    sym = getattr(order, "symbol", None)
    if sym is None and isinstance(order, dict):
        sym = order.get("symbol")
    if sym:
        try:
            self.get_position(sym, force_refresh=True)
        except TypeError:
            self.get_position(sym)

async def sync_positions(self):
    """
    Периодическая синхронизация: перечитать все позиции и обновить кэш.
    """
    positions = await self.get_positions()
    for p in positions:
        sym = getattr(p, "symbol", None)
        if sym:
            self._positions_cache[sym] = p


    def get_all_positions(self, force_refresh: bool = False) -> List[Position]:
        """
        Get all open positions.
        
        Args:
            force_refresh: Force refresh from API
        
        Returns:
            List of Position objects
        """
        try:
            positions = []
            position_data = self.client.get_position_info()
            
            for pos in position_data:
                symbol = pos["symbol"]
                position_amt = float(pos.get("positionAmt", "0"))
                
                if abs(position_amt) > 1e-8:  # Only include non-zero positions
                    position = Position(
                        symbol=symbol,
                        side=1 if position_amt > 0 else -1,
                        size=abs(position_amt),
                        entry_price=float(pos.get("entryPrice", "0")),
                        unrealized_pnl=float(pos.get("unPnl", "0")),
                        timestamp=datetime.now()
                    )
                    positions.append(position)
                    
                    # Update cache
                    self._positions_cache[symbol] = position
            
            self._last_update = datetime.now().timestamp()
            return positions
            
        except Exception as e:
            logger.error(f"Failed to get all positions: {e}")
            return []
    
    def get_account_balance(self) -> float:
        """
        Get account balance in USDT.
        
        Returns:
            USDT balance
        """
        try:
            balance_data = self.client.get_account_balance()
            
            for asset in balance_data:
                if asset["asset"] == "USDT":
                    return float(asset["balance"])
            
            return 0.0
            
        except Exception as e:
            logger.error(f"Failed to get account balance: {e}")
            return 0.0
    
    def calculate_position_size(self, symbol: str, entry_price: float, 
                              stop_loss_price: float) -> float:
        """
        Calculate position size based on risk management rules.
        
        Args:
            symbol: Trading symbol
            entry_price: Intended entry price
            stop_loss_price: Stop loss price
        
        Returns:
            Position size in base asset
        """
        try:
            # Get account balance
            balance = self.get_account_balance()
            if balance <= 0:
                return 0.0
            
            # Calculate risk amount
            risk_amount = balance * (self.config.risk_per_trade_pct / 100.0)
            
            # Calculate stop loss distance
            if stop_loss_price <= 0:
                sl_distance = entry_price * (self.config.sl_fixed_pct / 100.0)
            else:
                sl_distance = abs(entry_price - stop_loss_price)
            
            if sl_distance <= 0:
                return 0.0
            
            # Calculate position size
            # risk_amount = position_size * entry_price * (sl_distance / entry_price)
            # position_size = risk_amount / sl_distance
            position_size = risk_amount / sl_distance
            
            # Apply leverage
            position_size *= self.config.leverage
            
            # Apply minimum notional constraints
            min_notional = self.config.min_notional_usdt
            if position_size * entry_price < min_notional:
                position_size = min_notional / entry_price
            
            return position_size
            
        except Exception as e:
            logger.error(f"Failed to calculate position size for {symbol}: {e}")
            return 0.0
    
    def get_position_risk_metrics(self, symbol: str) -> Dict[str, float]:
        """
        Calculate risk metrics for a position.
        
        Args:
            symbol: Trading symbol
        
        Returns:
            Dictionary of risk metrics
        """
        position = self.get_position(symbol)
        balance = self.get_account_balance()
        
        if position.is_flat or balance <= 0:
            return {
                "position_size_usd": 0.0,
                "account_risk_pct": 0.0,
                "leverage_used": 0.0,
                "unrealized_pnl_pct": 0.0
            }
        
        try:
            # Current market price
            ticker = self.client.get_ticker_price(symbol)
            current_price = float(ticker["price"])
            
            # Position value
            position_value = position.size * current_price
            
            # Account risk percentage
            account_risk_pct = (position_value / balance) * 100.0 / self.config.leverage
            
            # Leverage actually used
            leverage_used = position_value / balance
            
            # Unrealized P&L percentage
            unrealized_pnl_pct = (position.unrealized_pnl / balance) * 100.0
            
            return {
                "position_size_usd": position_value,
                "account_risk_pct": account_risk_pct,
                "leverage_used": leverage_used,
                "unrealized_pnl_pct": unrealized_pnl_pct
            }
            
        except Exception as e:
            logger.error(f"Failed to calculate risk metrics for {symbol}: {e}")
            return {
                "position_size_usd": 0.0,
                "account_risk_pct": 0.0,
                "leverage_used": 0.0,
                "unrealized_pnl_pct": 0.0
            }
    
    def setup_symbol(self, symbol: str) -> bool:
        """
        Setup symbol for trading (leverage, margin type, etc.).
        
        Args:
            symbol: Trading symbol
        
        Returns:
            True if successful
        """
        try:
            # Set leverage
            self.client.change_leverage(symbol, self.config.leverage)
            logger.info(f"Set leverage for {symbol}: {self.config.leverage}x")
            
            # Set margin type (ISOLATED/CROSSED)
            margin_type = "ISOLATED"  # Default to isolated margin
            try:
                self.client.change_margin_type(symbol, margin_type)
                logger.info(f"Set margin type for {symbol}: {margin_type}")
            except Exception:
                # Margin type might already be set, ignore error
                pass
            
            # Set position mode (ONE-WAY/HEDGE)
            try:
                dual_side = False  # Use one-way mode by default
                self.client.change_position_mode(dual_side)
                logger.info(f"Set position mode: {'HEDGE' if dual_side else 'ONE-WAY'}")
            except Exception:
                # Position mode might already be set, ignore error
                pass
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to setup symbol {symbol}: {e}")
            return False
    
    def clear_cache(self, symbol: Optional[str] = None) -> None:
        """
        Clear position cache.
        
        Args:
            symbol: Clear cache for specific symbol, or all if None
        """
        if symbol:
            self._positions_cache.pop(symbol, None)
        else:
            self._positions_cache.clear()
            
        logger.debug(f"Cleared position cache for {symbol or 'all symbols'}")
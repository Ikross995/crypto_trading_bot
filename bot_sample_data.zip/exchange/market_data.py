"""
Market data module for AI Trading Bot.

Provides market data provider classes and utilities for backward compatibility.
Main market data functionality is handled by data.fetchers and exchange.client.
"""

import logging
from typing import Any, Dict, List, Optional

from core.types import MarketData

logger = logging.getLogger(__name__)


class MarketDataProvider:
    """
    Market data provider for backward compatibility.
    
    This is a minimal implementation to ensure imports work correctly.
    Real market data functionality is handled by:
    - data.fetchers.DataFetcher for historical data
    - exchange.client.BinanceClient for live data
    """
    
    def __init__(self, client: Optional[Any] = None):
        """Initialize market data provider."""
        self.client = client
        logger.debug("MarketDataProvider initialized")
    
    async def get_klines(self, symbol: str, interval: str, limit: int = 500) -> List[Dict[str, Any]]:
        """Get historical kline data."""
        logger.debug(f"Getting klines for {symbol} {interval} (limit={limit})")
        
        if self.client and hasattr(self.client, 'get_klines'):
            return await self.client.get_klines(symbol, interval, limit)
        
        # Fallback - return empty list
        logger.warning("No client available for klines data")
        return []
    
    async def get_ticker_price(self, symbol: str) -> Dict[str, Any]:
        """Get current ticker price."""
        logger.debug(f"Getting ticker price for {symbol}")
        
        if self.client and hasattr(self.client, 'get_symbol_price'):
            price = await self.client.get_symbol_price(symbol)
            return {"symbol": symbol, "price": str(price)}
        
        # Fallback - return default structure
        logger.warning("No client available for ticker price")
        return {"symbol": symbol, "price": "0.0"}
    
    async def get_market_data(self, symbol: str, timeframe: str = "1m") -> Optional[MarketData]:
        """Get current market data for symbol."""
        logger.debug(f"Getting market data for {symbol} {timeframe}")
        
        # This is a placeholder implementation
        # Real market data should be obtained from data.fetchers or exchange.client
        return None

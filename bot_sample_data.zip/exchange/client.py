# exchange/client.py
"""
Integrated Binance futures client for the project's exchange layer.

Features ported from monolith:
- SAFE SIGNATURE PATCH: add recvWindow BEFORE signing, never mutate payload post-sign
- safe_call(): retries on -1021 (time desync), reconnects once on transport issues,
  hard-stops on 401/403/-2015/-2014
- REST fallback for order placement and open-orders retrieval when python-binance SDK glitches
- Testnet/Live switching via config, DRY_RUN mode

Compatibility shims added for the modular runner:
- MockBinanceClient (alias) for paper tests
- BinanceMarketDataClient with .initialize(), .get_current_price(), .get_klines()
- IntegratedBinanceClient(config) initializer
- create_client(config, *, market_data=False, mock=False) factory
- Extra public methods used by order/strategy layers: get_ticker_price(), get_klines(), close()

Public methods preserved:
    * get_exchange_info()
    * get_open_orders(symbol: str | None = None)
    * place_order(**order_params)
    * cancel_order(symbol: str, orderId: int | None = None, origClientOrderId: str | None = None)
    * get_account_balance()
    * get_positions()
    * change_leverage(symbol: str, leverage: int)
    * change_margin_type(symbol: str, marginType: str)
    * change_position_mode(dualSidePosition: bool)
    * get_mark_price(symbol: str)
    * get_historical_klines(symbol: str, interval: str, start_str: str, end_str: str | None, limit: int = 1500)
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import os
import time
from typing import Any, Dict, Optional, List

import requests

from core.config import get_config, Config
from core.constants import TradingMode

logger = logging.getLogger(__name__)

# --- Optional SDK import (we'll work even if missing) ---
try:
    from binance.client import Client as _BinanceClient
    from binance.exceptions import BinanceAPIException
    _SDK = "binance"
except Exception:  # pragma: no cover - optional
    _BinanceClient = None
    class BinanceAPIException(Exception):  # minimal shim
        def __init__(self, status_code=None, message="", code=None):
            super().__init__(message)
            self.status_code = status_code
            self.code = code
    _SDK = None


def _base_urls(testnet: bool) -> Dict[str, str]:
    return {
        "rest": "https://testnet.binancefuture.com" if testnet else "https://fapi.binance.com",
        "ws":   "wss://stream.binancefuture.com" if testnet else "wss://fstream.binance.com",
    }


class BinanceClient:
    """
    Wrapper over python-binance REST for UM Futures with resilient behaviour.

    This class is safe to use in both LIVE and PAPER modes.
    If API keys are missing or MODE!=live, it will still instantiate but skip real trading when DRY_RUN=true.
    """

    # NOTE: расширили сигнатуру для совместимости с IntegratedBinanceClient(config)
    def __init__(
        self,
        config: Optional[Config] = None,
        *,
        testnet: Optional[bool] = None,
        api_key: Optional[str] = None,
        api_secret: Optional[str] = None,
        dry_run: Optional[bool] = None
    ) -> None:
        # Загрузим глобальный конфиг, затем перекроем параметрами конструктора (если переданы)
        self.cfg: Config = config or get_config()

        self.session = requests.Session()

        # Определяем testnet/dry_run
        self.testnet = bool(
            self._coalesce(
                testnet,
                getattr(self.cfg, "testnet", getattr(self.cfg, "TESTNET", True))
            )
        )
        self._base = _base_urls(self.testnet)["rest"]

        self.mode = getattr(self.cfg, "mode", TradingMode.PAPER)
        self.dry_run = bool(
            self._coalesce(
                dry_run,
                getattr(self.cfg, "dry_run", getattr(self.cfg, "DRY_RUN", False))
            )
        )

        # Ключи (приоритет у параметров конструктора)
        self.api_key = (api_key or self.cfg.binance_api_key or os.getenv("BINANCE_API_KEY") or "").strip()
        self.api_secret = (api_secret or self.cfg.binance_api_secret or os.getenv("BINANCE_API_SECRET") or os.getenv("BINANCE_SECRET_KEY") or "").strip()

        # Underlying SDK client if available
        self.client: Optional[_BinanceClient] = None
        if _BinanceClient:
            try:
                self.client = _BinanceClient(api_key=self.api_key, api_secret=self.api_secret, testnet=self.testnet)
                # force UM base url
                try:
                    self.client.API_URL = self._base
                except Exception:
                    pass
            except Exception as e:  # pragma: no cover
                logger.warning("Failed to init python-binance client: %s", e)

        # One-shot time sync memo
        self._last_time_sync = 0.0

    # utility
    @staticmethod
    def _coalesce(*values):
        for v in values:
            if v is not None:
                return v
        return None

    # -------------------- SAFE CALL WRAPPER --------------------
    def safe_call(self, fn, *args, **kwargs):
        """
        Wrapper around SDK calls:
        - retry once on -1021 after time sync
        - recreate client on transport errors (_http missing etc.)
        - hard-fail on auth errors 401/403/-2015/-2014
        """
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            status = getattr(e, "status_code", None)
            code = getattr(e, "code", None)
            msg = str(e)

            # Auth errors: do not retry
            if status in (401, 403) or code in (-2015, -2014):
                raise

            # Timestamp / recvWindow issues
            if code == -1021 or "recvWindow" in msg or "outside of the recvWindow" in msg:
                self._sync_time()
                time.sleep(1.0)
                return fn(*args, **kwargs)

            # Transport glitches: recreate client once
            if any(s in msg for s in ("_http", "send_request", "Connection", "Read timed out")):
                try:
                    self._recreate_client()
                    return fn(*args, **kwargs)
                except Exception:
                    pass

            # bubble up
            raise

    def _recreate_client(self):
        if _BinanceClient is None:
            return
        self.client = _BinanceClient(api_key=self.api_key, api_secret=self.api_secret, testnet=self.testnet)
        try:
            self.client.API_URL = self._base
        except Exception:
            pass

    def _sync_time(self):
        now = time.time()
        if self.client is None or (now - self._last_time_sync) < 2.0:
            return
        try:
            _ = self.safe_call(self.client.futures_time)
            self._last_time_sync = now
        except Exception:
            pass

    # -------------------- SAFE SIGNING + REST FALLBACK --------------------
    def _headers(self) -> Dict[str, str]:
        return {"X-MBX-APIKEY": self.api_key, "Content-Type": "application/x-www-form-urlencoded"}

    def _sign(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        SAFE SIGNATURE PATCH:
        Add recvWindow BEFORE signing and NEVER mutate payload post-signature.
        """
        p = dict(payload or {})
        recv = int(getattr(self.cfg, "recv_window_ms", getattr(self.cfg, "RECV_WINDOW_MS", 7000)))
        p.setdefault("timestamp", int(time.time() * 1000))
        p.setdefault("recvWindow", recv)
        q = "&".join(f"{k}={p[k]}" for k in sorted(p.keys()) if p[k] is not None)
        sig = hmac.new(self.api_secret.encode("utf-8"), q.encode("utf-8"), hashlib.sha256).hexdigest()
        p["signature"] = sig
        return p

    def _rest(self, method: str, path: str, payload: Dict[str, Any]) -> Any:
        url = self._base + path
        signed = self._sign(payload)
        try:
            if method == "GET":
                r = self.session.get(url, params=signed, headers=self._headers(), timeout=10)
            elif method == "POST":
                r = self.session.post(url, params=signed, headers=self._headers(), timeout=10)
            elif method == "DELETE":
                r = self.session.delete(url, params=signed, headers=self._headers(), timeout=10)
            else:
                raise RuntimeError(f"Unsupported method {method}")
            data = r.json() if r.headers.get("content-type","").startswith("application/json") else {"status": r.status_code, "text": r.text}
            if not r.ok:
                raise RuntimeError(f"REST {method} {path} failed [{r.status_code}]: {data}")
            return data
        except Exception as e:
            logger.error("REST call failed: %s %s payload=%s err=%s", method, path, payload, e)
            raise

    # Публичные (без подписи) REST вызовы — для тикера/клайнов, когда SDK недоступен
    def _rest_public(self, method: str, path: str, params: Dict[str, Any]) -> Any:
        url = self._base + path
        try:
            if method == "GET":
                r = self.session.get(url, params=params, timeout=10)
            else:
                raise RuntimeError(f"Unsupported public method {method}")
            data = r.json() if r.headers.get("content-type","").startswith("application/json") else {"status": r.status_code, "text": r.text}
            if not r.ok:
                raise RuntimeError(f"REST PUBLIC {method} {path} failed [{r.status_code}]: {data}")
            return data
        except Exception as e:
            logger.error("REST public call failed: %s %s params=%s err=%s", method, path, params, e)
            raise

    # -------------------- PUBLIC API COMPATIBILITY --------------------
    def get_exchange_info(self) -> Dict[str, Any]:
        if self.client:
            try:
                return self.safe_call(self.client.futures_exchange_info)
            except Exception:
                pass
        # REST fallback
        return self._rest("GET", "/fapi/v1/exchangeInfo", {})

    def get_open_orders(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        if self.client:
            try:
                if symbol:
                    return self.safe_call(self.client.futures_get_open_orders, symbol=symbol.upper())
                return self.safe_call(self.client.futures_get_open_orders)
            except Exception as e:
                msg = str(e)
                if "_http" not in msg and "send_request" not in msg:
                    raise
        payload: Dict[str, Any] = {}
        if symbol:
            payload["symbol"] = symbol.upper()
        data = self._rest("GET", "/fapi/v1/openOrders", payload)
        return data if isinstance(data, list) else []

    def cancel_order(self, symbol: str, orderId: Optional[int] = None, origClientOrderId: Optional[str] = None) -> Dict[str, Any]:
        if self.dry_run:
            return {"symbol": symbol.upper(), "status": "CANCELED", "orderId": orderId or 0, "origClientOrderId": origClientOrderId or ""}
        if self.client:
            try:
                return self.safe_call(self.client.futures_cancel_order, symbol=symbol.upper(), orderId=orderId, origClientOrderId=origClientOrderId)
            except Exception as e:
                msg = str(e)
                if "_http" not in msg and "send_request" not in msg:
                    raise
        return self._rest("DELETE", "/fapi/v1/order", {"symbol": symbol.upper(), "orderId": orderId, "origClientOrderId": origClientOrderId})

    def place_order(self, **order_params) -> Dict[str, Any]:
        """
        General order placement entry point used by exchange.orders.
        Accepts usual futures params: symbol, side, type, quantity, price, timeInForce,
        reduceOnly, stopPrice, workingType, closePosition, positionSide.
        """
        params = {k: v for k, v in order_params.items() if v is not None}
        symbol = (params.get("symbol") or "").upper()
        if self.dry_run or not self.api_key or not self.api_secret:
            # simulate acknowledgment
            return {
                "symbol": symbol,
                "status": "FILLED" if params.get("type") == "MARKET" else "NEW",
                "type": params.get("type"),
                "side": params.get("side"),
                "price": params.get("price"),
                "stopPrice": params.get("stopPrice"),
                "origQty": params.get("quantity"),
                "executedQty": params.get("quantity") if params.get("type") == "MARKET" else "0",
                "reduceOnly": params.get("reduceOnly", False),
                "closePosition": params.get("closePosition", False),
            }

        # Try SDK first
        if self.client:
            try:
                return self.safe_call(self.client.futures_create_order, **params)
            except Exception as e:
                msg = str(e)
                # Fallback on transport/signature issues
                if "_http" in msg or "send_request" in msg or "Signature" in msg or "timestamp" in msg:
                    pass
                else:
                    raise
        # REST fallback
        return self._rest("POST", "/fapi/v1/order", params)

    # --- Misc endpoints required by other modules ---
    def get_account_balance(self) -> float:
        if self.client:
            try:
                acc = self.safe_call(self.client.futures_account_balance)
                # Find USDT balance
                for it in acc:
                    if it.get("asset") in ("USDT","BUSD","USD"):
                        return float(it.get("balance", 0.0))
            except Exception:
                pass
        try:
            data = self._rest("GET", "/fapi/v2/balance", {})
            for it in data:
                if it.get("asset") in ("USDT","BUSD","USD"):
                    return float(it.get("balance", 0.0))
        except Exception:
            pass
        return 0.0

    def get_positions(self) -> List[Dict[str, Any]]:
        if self.client:
            try:
                return self.safe_call(self.client.futures_position_information)
            except Exception:
                pass
        try:
            return self._rest("GET", "/fapi/v2/positionRisk", {})
        except Exception:
            return []

    def change_leverage(self, symbol: str, leverage: int) -> Dict[str, Any]:
        if self.client:
            try:
                return self.safe_call(self.client.futures_change_leverage, symbol=symbol.upper(), leverage=int(leverage))
            except Exception:
                pass
        return self._rest("POST", "/fapi/v1/leverage", {"symbol": symbol.upper(), "leverage": int(leverage)})

    def change_margin_type(self, symbol: str, marginType: str) -> Dict[str, Any]:
        if self.client:
            try:
                return self.safe_call(self.client.futures_change_margin_type, symbol=symbol.upper(), marginType=str(marginType).upper())
            except Exception:
                pass
        return self._rest("POST", "/fapi/v1/marginType", {"symbol": symbol.upper(), "marginType": str(marginType).upper()})

    def change_position_mode(self, dualSidePosition: bool) -> Dict[str, Any]:
        if self.client:
            try:
                return self.safe_call(self.client.futures_change_position_mode, dualSidePosition=bool(dualSidePosition))
            except Exception:
                pass
        return self._rest("POST", "/fapi/v1/positionSide/dual", {"dualSidePosition": "true" if bool(dualSidePosition) else "false"})

    def get_mark_price(self, symbol: str) -> float:
        if self.client:
            try:
                data = self.safe_call(self.client.futures_mark_price, symbol=symbol.upper())
                return float(data.get("markPrice", 0.0))
            except Exception:
                pass
        try:
            data = self._rest("GET", "/fapi/v1/premiumIndex", {"symbol": symbol.upper()})
            return float(data.get("markPrice", 0.0))
        except Exception:
            return 0.0

    # --- Added for order/strategy compatibility ---
    def get_ticker_price(self, symbol: str) -> Dict[str, str]:
        """
        Return {"symbol": ..., "price": "..."} using SDK when available, otherwise public REST.
        Used by OrderManager._get_current_price().
        """
        if self.client and hasattr(self.client, "futures_symbol_ticker"):
            try:
                data = self.safe_call(self.client.futures_symbol_ticker, symbol=symbol.upper())
                # SDK may return {'symbol': 'BTCUSDT', 'price': '67321.12'}
                return {"symbol": data.get("symbol", symbol.upper()), "price": str(data.get("price", "0"))}
            except Exception:
                pass
        data = self._rest_public("GET", "/fapi/v1/ticker/price", {"symbol": symbol.upper()})
        if isinstance(data, dict):
            return {"symbol": data.get("symbol", symbol.upper()), "price": str(data.get("price", "0"))}
        # fallback shape
        return {"symbol": symbol.upper(), "price": "0"}

    def get_klines(self, symbol: str, interval: str, limit: int = 500) -> List[List[Any]]:
        """
        Futures klines (public). Used by MarketData client.
        """
        if self.client and hasattr(self.client, "futures_klines"):
            try:
                return self.safe_call(self.client.futures_klines, symbol=symbol.upper(), interval=interval, limit=int(limit))
            except Exception:
                pass
        data = self._rest_public("GET", "/fapi/v1/klines", {"symbol": symbol.upper(), "interval": interval, "limit": int(limit)})
        return data if isinstance(data, list) else []

    def get_historical_klines(self, symbol: str, interval: str, start_str: str, end_str: Optional[str] = None, limit: int = 1500):
        """
        Keep SDK path when available (spot client has helper); otherwise approximate with klines + limit.
        """
        if self.client and hasattr(self.client, "get_historical_klines"):
            try:
                return self.safe_call(self.client.get_historical_klines, symbol, interval, start_str, end_str, limit)
            except Exception:
                pass
        # Minimal fallback: just return recent klines
        return self.get_klines(symbol, interval, limit=limit)

    def close(self):
        """Graceful shutdown for runner.live/paper."""
        try:
            self.session.close()
        except Exception:
            pass

# -------------------- COMPATIBILITY SHIMS --------------------

class IntegratedBinanceClient(BinanceClient):
    """Thin wrapper to accept Config in constructor like IntegratedBinanceClient(config)."""
    def __init__(self, config: Config):
        super().__init__(config=config)

class BinanceMarketDataClient:
    """
    Lightweight market data facade used by runner.paper/live:
    - initialize()
    - get_current_price(symbol) -> float
    - get_klines(symbol, interval, limit=...)
    """
    def __init__(self, config: Optional[Config] = None):
        self.config = config or get_config()
        # В режиме paper/testnet — всё равно используем наш общий клиент
        self.client = BinanceClient(self.config)

    def initialize(self):
        # Просто проверим коннект/обменник (поддерживаем старый контракт)
        _ = self.client.get_exchange_info()

    def get_current_price(self, symbol: str) -> float:
        # Если нужна «рыночная» цена — берём mark price (или тикер в запас)
        mp = self.client.get_mark_price(symbol)
        if mp and mp > 0:
            return float(mp)
        try:
            t = self.client.get_ticker_price(symbol)
            return float(t.get("price", 0.0))
        except Exception:
            return 0.0

    def get_klines(self, symbol: str, interval: str, limit: int = 150):
        return self.client.get_klines(symbol, interval, limit=limit)

# Для старых импортов
MockBinanceClient = BinanceClient

def create_client(config: Optional[Config] = None, *, market_data: bool = False, mock: bool = False):
    """
    Factory for legacy code paths:
      - create_client(config, market_data=True) -> BinanceMarketDataClient
      - create_client(config, mock=True)        -> MockBinanceClient
      - create_client(config)                   -> IntegratedBinanceClient
    """
    if market_data:
        return BinanceMarketDataClient(config)
    if mock:
        return MockBinanceClient(config)
    return IntegratedBinanceClient(config)

__all__ = [
    "BinanceClient",
    "IntegratedBinanceClient",
    "BinanceMarketDataClient",
    "MockBinanceClient",
    "create_client",
]

# sitecustomize.py
# Авто‑подключение совместимости при любом запуске в этом проекте
try:
    import compat
    compat.apply()
except Exception:
    # Безопасное молчаливое падение — чтобы не мешать прочим инструментам
    pass

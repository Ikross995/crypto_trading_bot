"""
Trading signal generation - Market Data Compatible Version

This version properly handles market data from the trading engine
and generates signals based on REAL prices, not synthetic ones.
"""

import logging
from typing import Optional, List, Dict, Any
from datetime import datetime, timezone
from dataclasses import dataclass

import numpy as np

from core.config import Config
try:
    from core.types import MarketData
except ImportError:
    # If MarketData doesn't exist, create a simple version
    @dataclass
    class MarketData:
        symbol: str
        timestamp: List[datetime]
        open: List[float]
        high: List[float]
        low: List[float]
        close: List[float]
        volume: List[float]

try:
    from core.constants import SignalType
except ImportError:
    # If SignalType doesn't exist, create it
    from enum import Enum
    class SignalType(Enum):
        BUY = "BUY"
        SELL = "SELL"
        HOLD = "HOLD"

# Create our own TradingSignal class since it's missing from core.types
@dataclass
class TradingSignal:
    """Trading signal data structure."""
    symbol: str
    signal_type: SignalType
    strength: float
    timestamp: datetime
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class SignalGenerator:
    """Generates trading signals based on REAL market data."""
    
    def __init__(self, config: Config):
        """Initialize signal generator with AGGRESSIVE configuration."""
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # ULTRA AGGRESSIVE Signal parameters - GUARANTEED to generate signals
        self.fast_ma_period = 5      # Very fast MA
        self.slow_ma_period = 10     # Very slow MA  
        self.min_signal_strength = 0.01  # Only 1% strength needed!
        
        # State tracking
        self.last_signal: Optional[TradingSignal] = None
        self.last_signal_time: Optional[datetime] = None
        self.signal_count = 0
        
        # Windows-compatible logging (no emoji)
        self.logger.info("ULTRA AGGRESSIVE SignalGenerator initialized (MARKET DATA COMPATIBLE)")
        self.logger.info(f"Min signal strength: {self.min_signal_strength}")
        self.logger.info(f"MA periods: {self.fast_ma_period}/{self.slow_ma_period}")
        self.logger.info("Ready to process REAL market data from API")
    
    async def initialize(self) -> None:
        """Initialize the signal generator - ASYNC VERSION."""
        self.logger.info("Signal generator initialized for REAL API TRADING")
    
    def generate_signal(self, market_data) -> Optional[TradingSignal]:
        """
        Generate trading signals based on REAL market data.
        
        This version prioritizes real market data over synthetic fallbacks.
        """
        self.signal_count += 1
        
        # Log what we received for debugging
        if market_data is None:
            self.logger.warning(f"Signal attempt #{self.signal_count}: market_data is None!")
            return self._generate_fallback_signal()
        
        # Extract symbol first to improve logging
        symbol = 'UNKNOWN'
        try:
            if hasattr(market_data, 'symbol'):
                symbol = market_data.symbol
            elif isinstance(market_data, dict):
                symbol = market_data.get('symbol', 'UNKNOWN')
            else:
                self.logger.warning(f"Signal attempt #{self.signal_count}: Unexpected market_data type: {type(market_data)}")
        except Exception as e:
            self.logger.warning(f"Error extracting symbol: {e}")
        
        self.logger.debug(f"Signal attempt #{self.signal_count} for {symbol}")
        
        # Handle different market_data structures - PREFER REAL DATA
        prices = None
        timestamps = None
        
        try:
            if hasattr(market_data, 'close') and hasattr(market_data, 'timestamp'):
                # This looks like real MarketData object
                prices = market_data.close
                timestamps = market_data.timestamp
                self.logger.debug(f"Using real MarketData: {len(prices)} prices for {symbol}")
                
            elif isinstance(market_data, dict):
                # Dictionary format market data
                prices = market_data.get('close', [])
                timestamps = market_data.get('timestamp', [])
                if prices:
                    self.logger.debug(f"Using dict market data: {len(prices)} prices for {symbol}")
                
            elif hasattr(market_data, '__dict__'):
                # Try to extract from any object with attributes
                attrs = vars(market_data)
                prices = attrs.get('close', attrs.get('prices', []))
                timestamps = attrs.get('timestamp', attrs.get('time', []))
                if prices:
                    self.logger.debug(f"Using object attributes: {len(prices)} prices for {symbol}")
            
            if not prices:
                self.logger.info(f"No price data available for {symbol}, checking fallback options")
                # Only use fallback for demo after trying real data
                if symbol == 'UNKNOWN' and self.signal_count % 5 == 0:
                    return self._generate_fallback_signal()
                return None
                
        except Exception as e:
            self.logger.error(f"Error extracting market data: {e}")
            return None
        
        # Validate we have enough data
        if not prices or len(prices) < max(self.slow_ma_period, 3):
            self.logger.debug(f"Insufficient price data for {symbol}: need {max(self.slow_ma_period, 3)}, got {len(prices)}")
            return None
            
        try:
            # Use recent prices for calculation
            recent_prices = list(prices[-20:]) if len(prices) >= 20 else list(prices)
            current_timestamp = timestamps[-1] if timestamps and len(timestamps) > 0 else datetime.now()
            
            # Calculate moving averages with real data
            if len(recent_prices) >= self.slow_ma_period:
                fast_ma = np.mean(recent_prices[-self.fast_ma_period:])
                slow_ma = np.mean(recent_prices[-self.slow_ma_period:])
            else:
                # Use what we have
                fast_ma = np.mean(recent_prices[-min(self.fast_ma_period, len(recent_prices)):])
                slow_ma = np.mean(recent_prices)
            
            current_price = recent_prices[-1]
            
            # Log REAL price data (not synthetic!)
            self.logger.debug(f"REAL PRICES - {symbol}: fast_ma={fast_ma:.4f}, slow_ma={slow_ma:.4f}, current={current_price:.4f}")
            
            # Check cooldown period
            if self._is_in_cooldown(current_timestamp):
                self.logger.debug(f"Still in cooldown for {symbol}")
                return None
            
            # ULTRA SENSITIVE signal detection using REAL prices
            signal_type = None
            strength = 0.0
            
            # Calculate MA difference percentage
            ma_diff_pct = abs(fast_ma - slow_ma) / slow_ma if slow_ma > 0 else 0
            
            if fast_ma > slow_ma:
                signal_type = SignalType.BUY
                strength = min(0.9, 0.5 + ma_diff_pct * 100)  # At least 50% strength
                
            elif fast_ma < slow_ma:
                signal_type = SignalType.SELL  
                strength = min(0.9, 0.5 + ma_diff_pct * 100)  # At least 50% strength
            
            # Secondary signal: price momentum with real data
            elif len(recent_prices) >= 2:
                price_change = (recent_prices[-1] - recent_prices[-2]) / recent_prices[-2]
                if abs(price_change) > 0.0001:  # 0.01% movement
                    signal_type = SignalType.BUY if price_change > 0 else SignalType.SELL
                    strength = min(0.85, 0.6 + abs(price_change) * 1000)
            
            # Check minimum strength (very low threshold)
            if not signal_type or strength < self.min_signal_strength:
                self.logger.debug(f"Signal rejected for {symbol}: type={signal_type}, strength={strength:.3f}, min_req={self.min_signal_strength}")
                return None
                
            # Create trading signal with REAL data
            signal = TradingSignal(
                symbol=symbol,
                signal_type=signal_type,
                strength=strength,
                timestamp=current_timestamp,
                metadata={
                    'fast_ma': float(fast_ma),
                    'slow_ma': float(slow_ma),
                    'current_price': float(current_price),
                    'ma_diff_pct': ma_diff_pct * 100,
                    'strategy': 'REAL_MARKET_DATA',
                    'signal_attempt': self.signal_count,
                    'data_points': len(recent_prices)
                }
            )
            
            self.last_signal = signal
            self.last_signal_time = current_timestamp
            
            # Log successful signal generation with REAL price
            self.logger.info(f"GENERATED {signal_type.value} signal for {symbol} "
                           f"(strength: {strength:.2f}, REAL_PRICE: {current_price:.4f}, attempt: #{self.signal_count})")
            
            return signal
            
        except Exception as e:
            self.logger.error(f"Error processing real market data for {symbol}: {e}")
            import traceback
            self.logger.error(traceback.format_exc())
            return None
    
    def _generate_fallback_signal(self) -> Optional[TradingSignal]:
        """Generate a fallback signal ONLY when real data is unavailable."""
        try:
            # Only use as last resort
            if self._is_in_cooldown(datetime.now()):
                return None
                
            signal_type = SignalType.BUY if (self.signal_count % 2) == 0 else SignalType.SELL
            
            # Use current BTC price range for more realistic fallback
            base_price = 67000.0  # Approximate current BTC price
            price_variation = (self.signal_count % 200) - 100  # ±100 variation
            fallback_price = base_price + price_variation
            
            signal = TradingSignal(
                symbol='BTCUSDT',
                signal_type=signal_type,
                strength=0.3,  # Lower strength for fallback signals
                timestamp=datetime.now(),
                metadata={
                    'fallback': True,
                    'fallback_price': fallback_price,
                    'strategy': 'FALLBACK_ONLY',
                    'signal_attempt': self.signal_count,
                    'note': 'Generated when real market data unavailable'
                }
            )
            
            self.last_signal = signal
            self.last_signal_time = datetime.now()
            
            # Clear indication this is fallback
            self.logger.warning(f"FALLBACK {signal_type.value} signal generated "
                              f"(strength: 0.3, fallback_price: {fallback_price:.2f}) - REAL DATA PREFERRED!")
            
            return signal
            
        except Exception as e:
            self.logger.error(f"Even fallback signal generation failed: {e}")
            return None
    
    def _is_in_cooldown(self, current_time: datetime) -> bool:
        """Check if we're still in cooldown period from last signal."""
        if not self.last_signal_time:
            return False
            
        cooldown_seconds = getattr(self.config, 'cooldown_sec', 10)  # Default 10 seconds
        
        # Handle timezone issues gracefully
        try:
            if current_time.tzinfo is None and self.last_signal_time.tzinfo is not None:
                current_time = current_time.replace(tzinfo=timezone.utc)
            elif current_time.tzinfo is not None and self.last_signal_time.tzinfo is None:
                self.last_signal_time = self.last_signal_time.replace(tzinfo=timezone.utc)
        except:
            pass  # Ignore timezone errors
        
        try:
            time_since_last = (current_time - self.last_signal_time).total_seconds()
        except:
            return False  # If time calculation fails, don't block
        
        is_cooling = time_since_last < cooldown_seconds
        if is_cooling:
            self.logger.debug(f"Cooldown: {time_since_last:.1f}s < {cooldown_seconds}s")
        
        return is_cooling
    
    def get_signal_summary(self) -> dict:
        """Get summary of signal generator state."""
        return {
            'fast_ma_period': self.fast_ma_period,
            'slow_ma_period': self.slow_ma_period,
            'min_signal_strength': self.min_signal_strength,
            'signal_count': self.signal_count,
            'market_data_compatible': True,
            'prefers_real_data': True,
            'last_signal': {
                'type': self.last_signal.signal_type.value if self.last_signal else None,
                'strength': self.last_signal.strength if self.last_signal else None,
                'timestamp': self.last_signal.timestamp.isoformat() if self.last_signal else None,
                'was_fallback': self.last_signal.metadata.get('fallback', False) if self.last_signal else False
            } if self.last_signal else None
        }


# Compatibility class if needed
class SimpleScalper:
    """Minimal scalper for compatibility."""
    
    def __init__(self, config: Config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
    async def initialize(self) -> None:
        """Async initialize for compatibility."""
        self.logger.info("SimpleScalper initialized")
        
    def generate_signal(self, market_data) -> Optional[TradingSignal]:
        """Simple scalping signal generation."""
        return None  # Not implemented in compatibility mode
